# Sequential B-Roll Video Processor

A reusable boilerplate for processing B-roll videos sequentially. This package can be easily integrated into any project and provides two main configurations:

1. **Interactive UI**: A web-based interface for uploading and processing B-roll videos
2. **Automated Processing**: A script that processes B-roll videos based on a configuration file

## Installation

### Prerequisites

- Python 3.7+
- MoviePy library

### Setup

1. Copy the entire `broll_processor_boilerplate` directory to your project
2. Install the required dependencies:

```bash
pip install moviepy streamlit
```

## Configuration 1: Interactive UI with Streamlit

This configuration provides a web-based interface for uploading and processing B-roll videos.

### Running the UI

```bash
cd broll_processor_boilerplate
streamlit run examples/streamlit_app.py
```

### Features

- Upload multiple B-roll videos
- Configure processing options
- View processing status in real-time
- Preview processed videos
- Export results to JSON
- Concatenate processed videos

## Configuration 2: Automated Processing

This configuration processes B-roll videos based on a JSON configuration file. This is useful when B-roll prompts are generated in a previous step.

### Running the Automated Processor

```bash
cd broll_processor_boilerplate
python examples/auto_processor.py examples/config.json
```

You can also override the output directory:

```bash
python examples/auto_processor.py examples/config.json --output-dir /path/to/output
```

### Configuration File Format

```json
{
  "output_dir": "./output",
  "job_data_file": "./jobs.json",
  "log_file": "./broll_processor.log",
  "concatenate": true,
  "save_results": true,
  "results_file": "results.json",
  "videos": {
    "segment1": {
      "path": "path/to/video1.mp4",
      "description": "First B-roll segment"
    },
    "segment2": {
      "path": "path/to/video2.mp4",
      "description": "Second B-roll segment"
    }
  }
}
```

## Integration Guide

### Integrating with Your Project

#### Option 1: Copy the Core Module Only

If you only need the core functionality:

1. Copy `src/broll_processor.py` to your project
2. Import the required classes:

```python
from broll_processor import SequentialBRollProcessor, ProcessingStatus
```

#### Option 2: Import as a Package

1. Copy the entire `broll_processor_boilerplate` directory to your project
2. Import the package:

```python
from broll_processor_boilerplate.src.broll_processor import SequentialBRollProcessor
```

### API Usage

```python
# Initialize the processor
processor = SequentialBRollProcessor(
    output_dir="./output",
    job_data_file="./jobs.json",
    log_file="./broll_processor.log"
)

# Define videos to process
videos = {
    "segment1": {
        "path": "path/to/video1.mp4",
        "description": "First B-roll segment"
    },
    "segment2": {
        "path": "path/to/video2.mp4",
        "description": "Second B-roll segment"
    }
}

# Define status change callback
def on_status_change(segment_id, status, message):
    print(f"Segment {segment_id}: {status} - {message}")

# Process videos sequentially
results = processor.process_videos_sequentially(
    videos=videos,
    on_status_change=on_status_change
)

# Concatenate successful videos
from broll_processor import concatenate_videos

successful_videos = [
    result["output_path"] 
    for result in results.values() 
    if result.get("success", False) and "output_path" in result
]

if successful_videos:
    concatenate_videos(successful_videos, "./output/concatenated_broll.mp4")
```

## Testing

To run the test script:

```bash
cd broll_processor_boilerplate
python tests/test_broll_processor.py
```

## License

MIT 