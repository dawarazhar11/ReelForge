#!/usr/bin/env python3
"""
Automated B-roll processor that reads from a configuration file
"""

import os
import sys
import json
import argparse
import logging
from pathlib import Path
from typing import Dict, Any, Optional

# Add src directory to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from broll_processor import SequentialBRollProcessor, ProcessingStatus, setup_logger

def load_config(config_path: str) -> Dict[str, Any]:
    """Load configuration from a JSON file
    
    Args:
        config_path: Path to the configuration file
        
    Returns:
        Dictionary containing configuration
    """
    try:
        with open(config_path, 'r') as f:
            config = json.load(f)
        return config
    except Exception as e:
        raise ValueError(f"Failed to load configuration: {str(e)}")

def process_broll_from_config(config_path: str, output_dir: Optional[str] = None) -> Dict[str, Any]:
    """Process B-roll videos based on configuration
    
    Args:
        config_path: Path to the configuration file
        output_dir: Override output directory (optional)
        
    Returns:
        Dictionary of processing results
    """
    # Load configuration
    config = load_config(config_path)
    
    # Set up logging
    log_file = config.get("log_file", "broll_processor.log")
    logger = setup_logger(
        name="auto_broll_processor",
        level=logging.INFO,
        log_file=log_file
    )
    
    logger.info(f"Loaded configuration from {config_path}")
    
    # Get output directory
    if output_dir is None:
        output_dir = config.get("output_dir", "./output")
    
    # Get job data file
    job_data_file = config.get("job_data_file", "jobs.json")
    
    # Get videos to process
    videos = config.get("videos", {})
    
    if not videos:
        logger.error("No videos found in configuration")
        return {"error": "No videos found in configuration"}
    
    logger.info(f"Found {len(videos)} videos to process")
    
    # Initialize processor
    processor = SequentialBRollProcessor(
        output_dir=output_dir,
        job_data_file=job_data_file,
        log_file=log_file
    )
    
    # Define status change callback
    def on_status_change(segment_id, status, message):
        logger.info(f"Segment {segment_id}: {status} - {message}")
    
    # Process videos
    logger.info(f"Starting sequential processing of {len(videos)} videos...")
    results = processor.process_videos_sequentially(
        videos=videos,
        on_status_change=on_status_change
    )
    
    # Count successful videos
    success_count = sum(1 for result in results.values() 
                      if isinstance(result, dict) and result.get("success", True))
    
    logger.info(f"Processing complete: {success_count}/{len(videos)} videos processed successfully")
    
    # Concatenate videos if requested
    if config.get("concatenate", True) and success_count > 0:
        from broll_processor import concatenate_videos
        
        # Get paths of successful videos
        successful_videos = [
            result["output_path"] 
            for result in results.values() 
            if result.get("success", False) and "output_path" in result
        ]
        
        if successful_videos:
            logger.info("Concatenating videos...")
            output_path = os.path.join(output_dir, "concatenated_broll.mp4")
            
            if concatenate_videos(successful_videos, output_path):
                logger.info(f"Videos concatenated successfully: {output_path}")
                
                # Add concatenated video to results
                results["concatenated"] = {
                    "success": True,
                    "output_path": output_path,
                    "is_concatenated": True
                }
            else:
                logger.error("Failed to concatenate videos")
    
    # Save results to file if requested
    if config.get("save_results", True):
        results_file = config.get("results_file", "results.json")
        results_path = os.path.join(output_dir, results_file)
        
        try:
            os.makedirs(os.path.dirname(os.path.abspath(results_path)), exist_ok=True)
            with open(results_path, 'w') as f:
                json.dump(results, f, indent=2)
            logger.info(f"Results saved to {results_path}")
        except Exception as e:
            logger.error(f"Failed to save results: {str(e)}")
    
    return results

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description="Automated B-roll processor")
    parser.add_argument("config", help="Path to configuration file")
    parser.add_argument("--output-dir", help="Override output directory")
    args = parser.parse_args()
    
    try:
        results = process_broll_from_config(args.config, args.output_dir)
        
        # Print summary
        success_count = sum(1 for result in results.values() 
                          if isinstance(result, dict) and result.get("success", True))
        total = len(results) - (1 if "concatenated" in results else 0)
        
        print(f"\nProcessing complete: {success_count}/{total} videos processed successfully")
        
        if "concatenated" in results:
            print(f"Concatenated video: {results['concatenated']['output_path']}")
        
        return 0
    except Exception as e:
        print(f"Error: {str(e)}")
        return 1

if __name__ == "__main__":
    sys.exit(main()) 