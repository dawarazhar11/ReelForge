#!/usr/bin/env python3
"""
Streamlit app for B-roll processor
"""

import os
import sys
import json
import time
import tempfile
from pathlib import Path
import streamlit as st

# Add src directory to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from broll_processor import SequentialBRollProcessor, ProcessingStatus

# Set page config
st.set_page_config(page_title="B-Roll Processor", layout="wide")

# App title
st.title("Sequential B-Roll Video Processor")

# Create sidebar for configuration
with st.sidebar:
    st.header("Configuration")
    
    # Output directory
    output_dir = st.text_input(
        "Output Directory", 
        value="./output",
        help="Directory where processed videos will be saved"
    )
    
    # Create directory if it doesn't exist
    if not os.path.exists(output_dir):
        if st.button("Create Output Directory"):
            os.makedirs(output_dir, exist_ok=True)
            st.success(f"Created directory: {output_dir}")
    
    # Job data file
    job_data_file = st.text_input(
        "Job Data File",
        value="./jobs.json",
        help="File to store job tracking data"
    )
    
    # Log file
    log_file = st.text_input(
        "Log File",
        value="./broll_processor.log",
        help="File to store logs"
    )
    
    # Advanced options expander
    with st.expander("Advanced Options"):
        temp_dir = st.text_input(
            "Temporary Directory",
            value=tempfile.gettempdir(),
            help="Directory for temporary files"
        )

# Main content area
tab1, tab2, tab3 = st.tabs(["Upload Videos", "Process Videos", "Results"])

# Global state for videos
if "videos" not in st.session_state:
    st.session_state.videos = {}

if "results" not in st.session_state:
    st.session_state.results = {}

# Upload Videos tab
with tab1:
    st.header("Upload B-Roll Videos")
    
    # Video upload
    uploaded_files = st.file_uploader(
        "Upload B-Roll Videos", 
        type=["mp4", "mov", "avi"], 
        accept_multiple_files=True
    )
    
    if uploaded_files:
        for uploaded_file in uploaded_files:
            # Save the file to disk
            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=f".{uploaded_file.name.split('.')[-1]}")
            temp_file.write(uploaded_file.getvalue())
            temp_file.close()
            
            # Generate segment ID
            segment_id = f"segment_{len(st.session_state.videos) + 1}"
            
            # Add to videos dictionary
            st.session_state.videos[segment_id] = {
                "path": temp_file.name,
                "original_name": uploaded_file.name,
                "description": f"Uploaded video: {uploaded_file.name}"
            }
        
        st.success(f"Uploaded {len(uploaded_files)} videos")
    
    # Display uploaded videos
    if st.session_state.videos:
        st.subheader("Uploaded Videos")
        
        for segment_id, video_data in st.session_state.videos.items():
            col1, col2 = st.columns([1, 3])
            
            with col1:
                st.text(segment_id)
            
            with col2:
                # Allow editing description
                video_data["description"] = st.text_input(
                    f"Description for {video_data['original_name']}",
                    value=video_data["description"],
                    key=f"desc_{segment_id}"
                )
        
        # Clear videos button
        if st.button("Clear All Videos"):
            # Delete temporary files
            for video_data in st.session_state.videos.values():
                try:
                    os.remove(video_data["path"])
                except:
                    pass
            
            st.session_state.videos = {}
            st.experimental_rerun()

# Process Videos tab
with tab2:
    st.header("Process B-Roll Videos")
    
    if not st.session_state.videos:
        st.warning("No videos uploaded. Please upload videos first.")
    else:
        st.info(f"{len(st.session_state.videos)} videos ready for processing")
        
        # Process button
        if st.button("Process Videos", type="primary"):
            # Create directories if they don't exist
            os.makedirs(os.path.dirname(os.path.abspath(job_data_file)), exist_ok=True)
            os.makedirs(os.path.dirname(os.path.abspath(log_file)), exist_ok=True)
            os.makedirs(output_dir, exist_ok=True)
            
            # Initialize processor
            processor = SequentialBRollProcessor(
                output_dir=output_dir,
                job_data_file=job_data_file,
                log_file=log_file,
                temp_dir=temp_dir
            )
            
            # Status area
            status_area = st.empty()
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            # Create result containers for each segment
            result_containers = {}
            for segment_id in st.session_state.videos.keys():
                result_containers[segment_id] = st.container()
            
            # Track progress
            completed = 0
            total = len(st.session_state.videos)
            
            # Define status change callback
            def on_status_change(segment_id, status, message):
                # Use session state to track completed count instead of nonlocal
                if status == ProcessingStatus.COMPLETED or status == ProcessingStatus.FAILED:
                    if not hasattr(st.session_state, 'completed_count'):
                        st.session_state.completed_count = 0
                    st.session_state.completed_count += 1
                
                # Update the result container for this segment
                with result_containers[segment_id]:
                    if status == ProcessingStatus.COMPLETED:
                        st.success(f"Segment {segment_id}: Completed - {message}")
                    elif status == ProcessingStatus.FAILED:
                        st.error(f"Segment {segment_id}: Failed - {message}")
                    else:
                        st.info(f"Segment {segment_id}: {status} - {message}")
                
                # Update progress
                current_completed = getattr(st.session_state, 'completed_count', 0)
                progress = current_completed / total if total > 0 else 0
                # Clamp progress value between 0 and 1
                progress = max(0.0, min(1.0, progress))
                progress_bar.progress(progress)
                status_text.text(f"Processing {current_completed} of {total} videos ({int(progress * 100)}%)")
            
            # Initialize completed count
            st.session_state.completed_count = 0
            
            # Start processing
            status_area.info(f"Starting sequential processing of {len(st.session_state.videos)} videos...")
            
            # Process videos
            results = processor.process_videos_sequentially(
                videos=st.session_state.videos,
                on_status_change=on_status_change
            )
            
            # Update final status
            success_count = sum(1 for result in results.values() 
                              if isinstance(result, dict) and result.get("success", True))
            
            status_area.success(f"Processing complete: {success_count}/{total} videos processed successfully")
            
            # Store results in session state
            st.session_state.results = results
            
            # Concatenate videos if all were successful
            if success_count == total:
                from broll_processor import concatenate_videos
                
                # Get paths of successful videos
                successful_videos = [
                    result["output_path"] 
                    for result in results.values() 
                    if result.get("success", False) and "output_path" in result
                ]
                
                if successful_videos:
                    st.info("Concatenating videos...")
                    output_path = os.path.join(output_dir, "concatenated_broll.mp4")
                    
                    if concatenate_videos(successful_videos, output_path):
                        st.success(f"Videos concatenated successfully: {output_path}")
                        
                        # Add concatenated video to results
                        st.session_state.results["concatenated"] = {
                            "success": True,
                            "output_path": output_path,
                            "is_concatenated": True
                        }
                    else:
                        st.error("Failed to concatenate videos")

# Results tab
with tab3:
    st.header("Processing Results")
    
    if not st.session_state.results:
        st.info("No processing results yet. Process some videos first.")
    else:
        # Display results
        for segment_id, result in st.session_state.results.items():
            if segment_id == "concatenated":
                st.subheader("Concatenated Video")
            else:
                st.subheader(f"Segment: {segment_id}")
            
            if result.get("success", False):
                st.success("Processing successful")
                
                # Display video if available
                output_path = result.get("output_path")
                if output_path and os.path.exists(output_path):
                    st.video(output_path)
                    
                    # Display metadata
                    if "metadata" in result:
                        with st.expander("Video Metadata"):
                            st.json(result["metadata"])
                    
                    # Display thumbnail if available
                    thumbnail_path = result.get("thumbnail_path")
                    if thumbnail_path and os.path.exists(thumbnail_path):
                        with st.expander("Thumbnail"):
                            st.image(thumbnail_path)
            else:
                st.error(f"Processing failed: {result.get('error', 'Unknown error')}")
        
        # Export results button
        if st.button("Export Results to JSON"):
            export_path = os.path.join(output_dir, "results.json")
            
            try:
                with open(export_path, "w") as f:
                    json.dump(st.session_state.results, f, indent=2)
                
                st.success(f"Results exported to {export_path}")
            except Exception as e:
                st.error(f"Failed to export results: {str(e)}")

# Footer
st.markdown("---")
st.markdown("B-Roll Processor Boilerplate | Made with ❤️") 