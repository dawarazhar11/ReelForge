#!/usr/bin/env python3
"""
Test script for the B-roll processor
"""

import os
import sys
import tempfile
from pathlib import Path
import importlib.util

# Add src directory to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from broll_processor import SequentialBRollProcessor, ProcessingStatus

# Check if moviepy is available
MOVIEPY_AVAILABLE = importlib.util.find_spec("moviepy") is not None

def create_dummy_video(path, duration=5):
    """Create a dummy video file for testing"""
    try:
        # Create a dummy file (we don't need real videos for testing the processor logic)
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, 'w') as f:
            f.write(f"Dummy video file with duration {duration}")
        print(f"Created dummy video file at {path}")
        return True
    except Exception as e:
        print(f"Error creating dummy video: {e}")
        return False

def test_broll_processor():
    """Test the B-roll processor"""
    print("Testing B-roll processor...")
    
    # Create temp directory for output
    with tempfile.TemporaryDirectory() as temp_dir:
        output_dir = os.path.join(temp_dir, "output")
        os.makedirs(output_dir, exist_ok=True)
        
        # Create job data file
        job_data_file = os.path.join(temp_dir, "jobs.json")
        
        # Create log file
        log_file = os.path.join(temp_dir, "broll_processor.log")
        
        # Initialize processor
        processor = SequentialBRollProcessor(
            output_dir=output_dir,
            job_data_file=job_data_file,
            log_file=log_file
        )
        
        # Create dummy videos
        video_dir = os.path.join(temp_dir, "videos")
        os.makedirs(video_dir, exist_ok=True)
        
        video1_path = os.path.join(video_dir, "video1.mp4")
        video2_path = os.path.join(video_dir, "video2.mp4")
        
        if not create_dummy_video(video1_path, duration=3):
            print("Failed to create dummy video 1")
            return False
        
        if not create_dummy_video(video2_path, duration=3):
            print("Failed to create dummy video 2")
            return False
        
        # Define videos to process
        videos = {
            "segment1": {
                "path": video1_path,
                "description": "First B-roll segment"
            },
            "segment2": {
                "path": video2_path,
                "description": "Second B-roll segment"
            }
        }
        
        # Define status change callback
        status_updates = []
        
        def on_status_change(segment_id, status, message):
            status_updates.append((segment_id, status, message))
            print(f"Segment {segment_id}: {status} - {message}")
        
        # Process videos sequentially
        print("\nProcessing videos...")
        results = processor.process_videos_sequentially(
            videos=videos,
            on_status_change=on_status_change
        )
        
        # Print results
        print("\nProcessing Results:")
        success_count = 0
        for segment_id, result in results.items():
            if result.get("success", False):
                print(f"Segment {segment_id}: Success - {result.get('output_path')}")
                success_count += 1
            else:
                print(f"Segment {segment_id}: Failed - {result.get('error')}")
        
        # Check if all videos were processed successfully
        if success_count == len(videos):
            print("\nAll videos processed successfully!")
            
            # Try concatenating videos
            successful_videos = [
                result["output_path"] 
                for result in results.values() 
                if result.get("success", False) and "output_path" in result
            ]
            
            if successful_videos:
                from broll_processor import concatenate_videos
                
                print("\nConcatenating videos...")
                output_path = os.path.join(output_dir, "concatenated_broll.mp4")
                if concatenate_videos(successful_videos, output_path):
                    print(f"Videos concatenated successfully: {output_path}")
                    return True
                else:
                    print("Failed to concatenate videos")
                    return False
        else:
            print(f"\nOnly {success_count}/{len(videos)} videos processed successfully")
            return False

if __name__ == "__main__":
    success = test_broll_processor()
    sys.exit(0 if success else 1) 